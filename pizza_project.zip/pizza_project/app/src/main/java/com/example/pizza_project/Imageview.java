package com.example.pizza_project;

public class Imageview {
    private int imageResource;

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }

    public int getImageResource() {
        return imageResource;
    }
}
